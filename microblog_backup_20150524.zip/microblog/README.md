#A Website by node.js#

---------------------------

##1. How to Install##

###1.1 For Ubuntu/Debian/..


	$sudo apt-get install node npm git -y


###1.2 For Red-Hat/Fedora/... :


	$sudo yum install node npm git -y


##2. How to use
###2.1 Clone this rep:

	$git clone git@github.com:3013216027/microblog.git

###2.2 Install the module needed:

	$npm install

###2.3 Start:

	$node app.js

###2.4 If you want to run it background:

	$nohup node app.js &

###2.5 If you DON'T want to get the message
by default, some log would be written into a file named 'nohup.out' if you run command of *2.4*, so if you don't like it, use this command instead:

	$nohup node app.js > /dev/null 2>&1 &

----------------------------

##3. Have Fun!
Now you can visit http://yourvpsIP or http://127.0.0.1/ (localhost, only in your own computer) to test it!

For any question, connact with zhengdongjian2013@gmail.com

^
